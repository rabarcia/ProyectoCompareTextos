package com.curso.android.app.practica.ejerciciofinal.model

data class Comparador(
    val text1: String,
    val text2: String,
    val sonIguales: Boolean
)
